export const jsonFile = {
  content: `{
    "version": 3,
    "id": "7c233295-e0e3-4767-8a90-40b00bf2e7fb",
    "address": "39b97205b9826f21fd39b535cf972c809e160e5f",
    "crypto": {
      "ciphertext": "076437cadf9726b105e87e04312fa087d5411d4da119b016c7f360625c909a05",
      "cipherparams": { "iv": "243d48a730d076fb9b75d77c7761e205" },
      "cipher": "aes-128-ctr",
      "kdf": "scrypt",
      "kdfparams": {
        "dklen": 32,
        "salt": "07ba5feeea26646399d3f32010240295884d2d4060bde6411cfd41e3ff94babe",
        "n": 131072,
        "r": 8,
        "p": 1
      },
      "mac": "eb01d6fa8b17a12943307c9c893e66ff0498dadca6134b3dce099a340225e08f"
    }
  }`,
  password: '1qazXSW@3edc',
};
