import AuthenticationModalPromise from './modal';
import AuthenticationPopupPromise from './popup';

export default AuthenticationPopupPromise;

export { AuthenticationModalPromise, AuthenticationPopupPromise };
