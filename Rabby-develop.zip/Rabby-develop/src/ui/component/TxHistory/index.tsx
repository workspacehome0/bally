export * from './TxAvatar';
export * from './TxChange';
export * from './TxId';
export * from './TxInterAddressExplain';
import './style.less';
