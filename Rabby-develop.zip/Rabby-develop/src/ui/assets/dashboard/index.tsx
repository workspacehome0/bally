export { ReactComponent as RcIconAddWalletCC } from './add-wallet-cc.svg';
