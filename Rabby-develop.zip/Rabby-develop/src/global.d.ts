declare module 'csstype' {
  interface Properties {
    '--background'?: string;
    [index: string]: any;
  }
}

declare module '*.md';
