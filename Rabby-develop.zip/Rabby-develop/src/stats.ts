import StatsReport, { SITE } from '@debank/festats';

export default new StatsReport(SITE.rabby);
