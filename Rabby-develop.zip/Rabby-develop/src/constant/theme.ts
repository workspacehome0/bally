export type AppColorsVariants = typeof import('@/constant/theme-colors').themeColors['light'];
