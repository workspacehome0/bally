export const APP_STORE_LINK =
  'https://apps.apple.com/us/app/rabby-wallet-crypto-evm/id6474381673';
export const GOOGLE_PLAY_LINK =
  'https://play.google.com/store/apps/details?id=com.debank.rabbymobile';
